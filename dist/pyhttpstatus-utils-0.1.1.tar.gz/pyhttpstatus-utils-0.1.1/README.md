<h2>pyhttpstatus-utils</h2>
<h3>Timezone conversion functions for Python.</h3>
<h4>Tue, 22 Nov 2016 19:25:44</h4>
<h4>Version: 0.1.1</h4>
===

Extension of python package pytz by providing timezone conversion functions.

Available functions:

<dl>
<dt></dt>
<dd><code>http_status_dict()</code></dd>

<dt></dt>
<dd><code>http_status_code_to_desc()</code></dd>

<dt></dt>
<dd><code>http_status_code_to_type()</code></dd>
<dt></dt>
<dd><code>is_http_status_type()</code></dd>
<dt></dt>
<dd><code>is_http_status_type()</code></dd>

</dl>


License: Apache 2.0